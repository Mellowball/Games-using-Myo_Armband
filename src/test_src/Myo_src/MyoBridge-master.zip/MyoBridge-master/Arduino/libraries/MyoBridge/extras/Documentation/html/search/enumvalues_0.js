var searchData=
[
  ['batterylevelcharacteristic',['BatteryLevelCharacteristic',['../group__myo__hardware.html#gga8912ee438db4275967233a844a8c36f1a5dc0cfdfaa7817966f1e86aa36bf5670',1,'myohw.h']]],
  ['batteryservice',['BatteryService',['../group__myo__hardware.html#gga8912ee438db4275967233a844a8c36f1a3c3085f75abeb351af41db8bb8c93e26',1,'myohw.h']]]
];

var group__utility__funcs =
[
    [ "connectionStatusToString", "group__utility__funcs.html#gacba3fc3a629cfe244feff21f521bff00", null ],
    [ "poseToString", "group__utility__funcs.html#ga280b0dfc78d0609ac8e431f4b1764902", null ]
];
var files =
[
    [ "MyoBridge.cpp", "_myo_bridge_8cpp.html", "_myo_bridge_8cpp" ],
    [ "MyoBridge.h", "_myo_bridge_8h.html", "_myo_bridge_8h" ],
    [ "MyoBridgeTypes.h", "_myo_bridge_types_8h.html", "_myo_bridge_types_8h" ],
    [ "myohw.h", "myohw_8h.html", "myohw_8h" ],
    [ "printFirmwareInfo.ino", "print_firmware_info_8ino.html", "print_firmware_info_8ino" ],
    [ "readEMGData.ino", "read_e_m_g_data_8ino.html", "read_e_m_g_data_8ino" ],
    [ "readIMUData.ino", "read_i_m_u_data_8ino.html", "read_i_m_u_data_8ino" ],
    [ "readPoseData.ino", "read_pose_data_8ino.html", "read_pose_data_8ino" ]
];
var searchData=
[
  ['tap_5fcount',['tap_count',['../struct_m_y_o_h_w___p_a_c_k_e_d_1_1_m_y_o_h_w___p_a_c_k_e_d_1_1_m_y_o_h_w___p_a_c_k_e_d.html#aeab5bdb212636f97fd2501fc3f0a785f',1,'MYOHW_PACKED::MYOHW_PACKED::MYOHW_PACKED']]],
  ['tap_5fdirection',['tap_direction',['../struct_m_y_o_h_w___p_a_c_k_e_d_1_1_m_y_o_h_w___p_a_c_k_e_d_1_1_m_y_o_h_w___p_a_c_k_e_d.html#ad1cf6de0a812705cb4f8f6ed8980f7ce',1,'MYOHW_PACKED::MYOHW_PACKED::MYOHW_PACKED']]],
  ['type',['type',['../struct_m_y_b_rsp_hdr__t.html#a786acdf67dc51092394d16010d79d43c',1,'MYBRspHdr_t::type()'],['../struct_m_y_o_h_w___p_a_c_k_e_d.html#a498825a3a7225af0560c53a88789067f',1,'MYOHW_PACKED::type()']]]
];

var searchData=
[
  ['getbatterylevel',['getBatteryLevel',['../group__basic__funcs.html#ga68e5ac3315ac5e8f4677eaafdb088bb7',1,'MyoBridge']]],
  ['getfirmwaremajor',['getFirmwareMajor',['../group__basic__funcs.html#ga356267611fd901901a70413f45e192e0',1,'MyoBridge']]],
  ['getfirmwareminor',['getFirmwareMinor',['../group__basic__funcs.html#gaf26706bf32f6cab745b5bef9b968c0b7',1,'MyoBridge']]],
  ['getfirmwarepatch',['getFirmwarePatch',['../group__basic__funcs.html#gafc70a718c92b0162fd43d10ffc1fbe5c',1,'MyoBridge']]],
  ['gethardwareaddress',['getHardwareAddress',['../group__basic__funcs.html#ga5e2132f6927345e166bd187f9ee6123d',1,'MyoBridge']]],
  ['gethardwarerevision',['getHardwareRevision',['../group__basic__funcs.html#gaf018a57459556dae7c1d153236ae65a0',1,'MyoBridge']]],
  ['getunlockpose',['getUnlockPose',['../group__basic__funcs.html#gab850c1decfbb452766f8e17e9c2599e9',1,'MyoBridge']]],
  ['gyroscope',['gyroscope',['../struct_m_y_o_h_w___p_a_c_k_e_d.html#a25898aa464d54419200cf89349d54c58',1,'MYOHW_PACKED']]]
];

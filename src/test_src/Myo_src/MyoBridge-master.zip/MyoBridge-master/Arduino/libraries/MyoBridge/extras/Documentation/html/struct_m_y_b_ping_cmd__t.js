var struct_m_y_b_ping_cmd__t =
[
    [ "hdr", "struct_m_y_b_ping_cmd__t.html#aefa896035c970453d25d1ade8cdc9568", null ]
];
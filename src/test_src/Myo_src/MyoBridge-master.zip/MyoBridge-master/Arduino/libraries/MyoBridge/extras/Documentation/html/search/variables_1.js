var searchData=
[
  ['bridge',['bridge',['../print_firmware_info_8ino.html#a1bbd37be74a749453817a3d174cd31b0',1,'bridge():&#160;printFirmwareInfo.ino'],['../read_e_m_g_data_8ino.html#a1bbd37be74a749453817a3d174cd31b0',1,'bridge():&#160;readEMGData.ino'],['../read_i_m_u_data_8ino.html#a1bbd37be74a749453817a3d174cd31b0',1,'bridge():&#160;readIMUData.ino'],['../read_pose_data_8ino.html#a1bbd37be74a749453817a3d174cd31b0',1,'bridge():&#160;readPoseData.ino']]]
];

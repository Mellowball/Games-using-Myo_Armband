var group__myb__rsp__structs =
[
    [ "MYBRspHdr_t", "struct_m_y_b_rsp_hdr__t.html", [
      [ "len", "struct_m_y_b_rsp_hdr__t.html#abd6992e35048a09732a7b5533e77153e", null ],
      [ "type", "struct_m_y_b_rsp_hdr__t.html#a786acdf67dc51092394d16010d79d43c", null ]
    ] ],
    [ "MYBDataRsp_t", "struct_m_y_b_data_rsp__t.html", [
      [ "characteristic", "struct_m_y_b_data_rsp__t.html#a4a8bbe850d15fae3c6e75987b1526c18", null ],
      [ "hdr", "struct_m_y_b_data_rsp__t.html#a210a198292fd2d89d324ad43825aad11", null ],
      [ "pData", "struct_m_y_b_data_rsp__t.html#a148e7d3567f30da277cfb0fd78a26755", null ]
    ] ],
    [ "MYBPingRsp_t", "struct_m_y_b_ping_rsp__t.html", [
      [ "hdr", "struct_m_y_b_ping_rsp__t.html#a5a417589db2447dea49c6164d47e6b84", null ]
    ] ],
    [ "MYBStatusRsp_t", "struct_m_y_b_status_rsp__t.html", [
      [ "hdr", "struct_m_y_b_status_rsp__t.html#a8bf6b8809d9cb64a27e00c925b18e421", null ],
      [ "status", "struct_m_y_b_status_rsp__t.html#a9e77fcc606195fd193673b676566397b", null ]
    ] ]
];
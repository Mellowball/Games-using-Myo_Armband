var searchData=
[
  ['major',['major',['../struct_m_y_o_h_w___p_a_c_k_e_d.html#a5da41e92849f0fffa7cb9d2b67ae1dcb',1,'MYOHW_PACKED']]],
  ['minor',['minor',['../struct_m_y_o_h_w___p_a_c_k_e_d.html#aed8361452196128daef385db9e9be077',1,'MYOHW_PACKED']]],
  ['myo_5fconnection_5fstate_5fstrings',['myo_connection_state_strings',['../_myo_bridge_8cpp.html#a2cee2fd79f21439b0a972372602f5374',1,'MyoBridge.cpp']]],
  ['myo_5fpose_5fstrings',['myo_pose_strings',['../_myo_bridge_8cpp.html#a2bfc7d4d0031c6072a4b948650f032e0',1,'MyoBridge.cpp']]]
];

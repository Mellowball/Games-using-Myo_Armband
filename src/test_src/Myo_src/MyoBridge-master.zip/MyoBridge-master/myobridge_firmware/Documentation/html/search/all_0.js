var searchData=
[
  ['accelerometer',['accelerometer',['../structmyohw__imu__data__t.html#acdbf0bf70f1e2377667e03a680767c5d',1,'myohw_imu_data_t']]],
  ['active_5fclassifier_5findex',['active_classifier_index',['../structmyohw__fw__info__t.html#a06e1d7aee9bdec73b0db29b65d9ebda5',1,'myohw_fw_info_t']]],
  ['active_5fclassifier_5ftype',['active_classifier_type',['../structmyohw__fw__info__t.html#ade18bb3fa175c088cbf9a1ad9c7c7953',1,'myohw_fw_info_t']]],
  ['arm',['arm',['../structmyohw__classifier__event__t.html#ab9f28e10cf6453e7951b711654804275',1,'myohw_classifier_event_t']]]
];

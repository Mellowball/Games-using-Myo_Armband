var _o_s_a_l___myo_bridge_8c =
[
    [ "osalInitTasks", "_o_s_a_l___myo_bridge_8c.html#a7ad49ef9f96d7753c3e77e0e69231bb2", null ],
    [ "tasksArr", "_o_s_a_l___myo_bridge_8c.html#aa0bf3a98b2f5dc74f19d24d0f63a2b68", null ],
    [ "tasksCnt", "_o_s_a_l___myo_bridge_8c.html#a1c008ff9f92b98c69fc68590ff42f15a", null ],
    [ "tasksEvents", "_o_s_a_l___myo_bridge_8c.html#ae0c7891223baf95ee28a0dcc4f0fd298", null ]
];
var searchData=
[
  ['firmwareversionchar',['firmwareVersionChar',['../struct_myo_handles__t.html#aa77cbd933134d40b565c9b0181455691',1,'MyoHandles_t']]],
  ['firmwareversioncharacteristic',['FirmwareVersionCharacteristic',['../group__myo__hardware.html#gga39811b63b77dda16ed982f292f034867a201e2cdce5699c8e1d23996cd4c6abf0',1,'myohw.h']]]
];

var group__myb__rsp__structs =
[
    [ "MYBRspHdr_t", "struct_m_y_b_rsp_hdr__t.html", [
      [ "len", "struct_m_y_b_rsp_hdr__t.html#a8ccac76f35f79d74917e1c5dd6f69fea", null ],
      [ "type", "struct_m_y_b_rsp_hdr__t.html#a0d5276797b2358f6093607c68006bde8", null ]
    ] ],
    [ "MYBDataRsp_t", "struct_m_y_b_data_rsp__t.html", [
      [ "characteristic", "struct_m_y_b_data_rsp__t.html#a3659f91b031ca049f617679f33511339", null ],
      [ "hdr", "struct_m_y_b_data_rsp__t.html#a24bd16a591720c16f2837216e61d72cc", null ],
      [ "pData", "struct_m_y_b_data_rsp__t.html#aea3016a10fc81479fa9f31e919029470", null ]
    ] ],
    [ "MYBPingRsp_t", "struct_m_y_b_ping_rsp__t.html", [
      [ "hdr", "struct_m_y_b_ping_rsp__t.html#a24bd16a591720c16f2837216e61d72cc", null ]
    ] ],
    [ "MYBStatusRsp_t", "struct_m_y_b_status_rsp__t.html", [
      [ "hdr", "struct_m_y_b_status_rsp__t.html#a24bd16a591720c16f2837216e61d72cc", null ],
      [ "status", "struct_m_y_b_status_rsp__t.html#ad94584ed274ed1d5b06d52f5bb3a178d", null ]
    ] ]
];
var searchData=
[
  ['emg_5fmode',['emg_mode',['../structmyohw__command__set__mode__t.html#a6ca68d5ffe417c8308775c8e5e1a1f0a',1,'myohw_command_set_mode_t']]],
  ['emgdata0',['emgData0',['../struct_myo_handles__t.html#aa6c88330f5202b2e99d592ea7329dc29',1,'MyoHandles_t']]],
  ['emgdata0characteristic',['EmgData0Characteristic',['../group__myo__hardware.html#gga39811b63b77dda16ed982f292f034867a57f16df1d88f45b6406b0dae9c3ddb1b',1,'myohw.h']]],
  ['emgdata1',['emgData1',['../struct_myo_handles__t.html#aa36fe738490b48bc8977067334682474',1,'MyoHandles_t']]],
  ['emgdata1characteristic',['EmgData1Characteristic',['../group__myo__hardware.html#gga39811b63b77dda16ed982f292f034867ae57e38c1aec0d35761112ced6b94aaeb',1,'myohw.h']]],
  ['emgdata2',['emgData2',['../struct_myo_handles__t.html#a5e85da9777984ce1d8332cdf50a8123f',1,'MyoHandles_t']]],
  ['emgdata2characteristic',['EmgData2Characteristic',['../group__myo__hardware.html#gga39811b63b77dda16ed982f292f034867ad3602d06599cad282167ab2fc7d8b2a4',1,'myohw.h']]],
  ['emgdata3',['emgData3',['../struct_myo_handles__t.html#a96d6821be7ac43fad15cb9ac4b6200a6',1,'MyoHandles_t']]],
  ['emgdata3characteristic',['EmgData3Characteristic',['../group__myo__hardware.html#gga39811b63b77dda16ed982f292f034867a37df066d48684b2e68cee256a173da24',1,'myohw.h']]],
  ['emgdataservice',['EmgDataService',['../group__myo__hardware.html#gga39811b63b77dda16ed982f292f034867a24616741af7080cf11b541e1f72212e8',1,'myohw.h']]],
  ['emgserviceend',['emgServiceEnd',['../struct_myo_handles__t.html#aa10ae6254e7509bbe932bd4315b803e4',1,'MyoHandles_t']]],
  ['emgservicestart',['emgServiceStart',['../struct_myo_handles__t.html#abb6a25d9a9cec102ae83d6acf5e3a968',1,'MyoHandles_t']]],
  ['erasebuffer',['eraseBuffer',['../serial_interface_8c.html#abb4064e006191544556aa558eb2ff8da',1,'eraseBuffer(uint16 bytes):&#160;serialInterface.c'],['../serial_interface_8h.html#abb4064e006191544556aa558eb2ff8da',1,'eraseBuffer(uint16 bytes):&#160;serialInterface.c']]]
];

var group__myb__data__structs =
[
    [ "MyoBridge Command Structures", "group__myb__cmd__structs.html", "group__myb__cmd__structs" ],
    [ "MyoBridge Response Structures", "group__myb__rsp__structs.html", "group__myb__rsp__structs" ],
    [ "MyoBridge OSAL Structures", "group__myb__osal__structs.html", "group__myb__osal__structs" ]
];
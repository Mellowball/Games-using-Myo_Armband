var searchData=
[
  ['characteristic',['characteristic',['../struct_m_y_b_data_rsp__t.html#a3659f91b031ca049f617679f33511339',1,'MYBDataRsp_t']]],
  ['classifier_5fmode',['classifier_mode',['../structmyohw__command__set__mode__t.html#aa4b4809321ee6f2a44b5d58b1a28199b',1,'myohw_command_set_mode_t']]],
  ['classifiereventcharacteristic',['ClassifierEventCharacteristic',['../group__myo__hardware.html#gga39811b63b77dda16ed982f292f034867ae308fd322e41ec31acc83595916ecbee',1,'myohw.h']]],
  ['classifierevents',['classifierEvents',['../struct_myo_handles__t.html#a7697b5b6c34329330385a75d49d6aada',1,'MyoHandles_t']]],
  ['classifierservice',['ClassifierService',['../group__myo__hardware.html#gga39811b63b77dda16ed982f292f034867af65db57e3874d5c5b8446809d10f1cca',1,'myohw.h']]],
  ['classifierserviceend',['classifierServiceEnd',['../struct_myo_handles__t.html#a056b2fd37cf1b681b52eccd26fa2df88',1,'MyoHandles_t']]],
  ['classifierservicestart',['classifierServiceStart',['../struct_myo_handles__t.html#aae23740d49342f138d577c94b15c9f13',1,'MyoHandles_t']]],
  ['cmd',['cmd',['../struct_m_y_b_cmd_hdr__t.html#a2bd2063db279997a5fe24fca0d36e4c5',1,'MYBCmdHdr_t']]],
  ['command',['command',['../structmyohw__command__header__t.html#afcfdcce17dfacc24d96cee293c6678db',1,'myohw_command_header_t']]],
  ['commandchar',['commandChar',['../struct_myo_handles__t.html#acfa4355d34d2c2dab7a4cdccc91f840f',1,'MyoHandles_t']]],
  ['commandcharacteristic',['CommandCharacteristic',['../group__myo__hardware.html#gga39811b63b77dda16ed982f292f034867adf8a8c3c0522f4cd9a4821600b1744b1',1,'myohw.h']]],
  ['controlservice',['ControlService',['../group__myo__hardware.html#gga39811b63b77dda16ed982f292f034867ad33871e3d686667c50ab78c9d8ea961c',1,'myohw.h']]],
  ['controlserviceend',['controlServiceEnd',['../struct_myo_handles__t.html#a765d36e8bc6645d105c9f01919e212a6',1,'MyoHandles_t']]],
  ['controlservicestart',['controlServiceStart',['../struct_myo_handles__t.html#adc5019bbf45cfb2bd40e48e4bdf579ee',1,'MyoHandles_t']]],
  ['cserialpacketparser',['cSerialPacketParser',['../serial_interface_8c.html#a6cc39a230e265c37fe2bbf08f9bcaba3',1,'cSerialPacketParser(uint8 port, uint8 events):&#160;serialInterface.c'],['../serial_interface_8h.html#a6cc39a230e265c37fe2bbf08f9bcaba3',1,'cSerialPacketParser(uint8 port, uint8 events):&#160;serialInterface.c']]],
  ['control_20commands',['Control Commands',['../group__myohw__control__commands.html',1,'']]]
];

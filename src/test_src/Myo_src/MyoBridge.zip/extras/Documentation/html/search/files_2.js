var searchData=
[
  ['reademgdata_2eino',['readEMGData.ino',['../read_e_m_g_data_8ino.html',1,'']]],
  ['readimudata_2eino',['readIMUData.ino',['../read_i_m_u_data_8ino.html',1,'']]],
  ['readme_2emd',['README.md',['../_r_e_a_d_m_e_8md.html',1,'']]],
  ['readposedata_2eino',['readPoseData.ino',['../read_pose_data_8ino.html',1,'']]]
];

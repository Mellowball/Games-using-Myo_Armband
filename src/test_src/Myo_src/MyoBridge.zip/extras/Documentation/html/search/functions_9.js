var searchData=
[
  ['sendcommand',['sendCommand',['../group__advanced__funcs.html#ga38ee56d816b6016b2eefc3581c6eb1ee',1,'MyoBridge']]],
  ['setemgdatacallback',['setEMGDataCallBack',['../group__callback__funcs.html#gab321a2fe2fc598fdc4b9c12a6cf8d100',1,'MyoBridge']]],
  ['setemgmode',['setEMGMode',['../group__basic__funcs.html#ga6d564f122e4fd5e3f3d968826ad21359',1,'MyoBridge']]],
  ['setimudatacallback',['setIMUDataCallBack',['../group__callback__funcs.html#ga03b432c626750b5a9c001c57537aba3b',1,'MyoBridge']]],
  ['setimumode',['setIMUMode',['../group__basic__funcs.html#ga2e522738fcd9353c2e2d55a4894b6fad',1,'MyoBridge']]],
  ['setimumotioncallback',['setIMUMotionCallBack',['../group__callback__funcs.html#ga2b3d5fa3fcde7b8095aa66aad87ea1f3',1,'MyoBridge']]],
  ['setposeeventcallback',['setPoseEventCallBack',['../group__callback__funcs.html#gac7feb1c5978e1f7064b879f60fcead6f',1,'MyoBridge']]],
  ['setup',['setup',['../print_firmware_info_8ino.html#a4fc01d736fe50cf5b977f755b675f11d',1,'setup():&#160;printFirmwareInfo.ino'],['../read_e_m_g_data_8ino.html#a4fc01d736fe50cf5b977f755b675f11d',1,'setup():&#160;readEMGData.ino'],['../read_i_m_u_data_8ino.html#a4fc01d736fe50cf5b977f755b675f11d',1,'setup():&#160;readIMUData.ino'],['../read_pose_data_8ino.html#a4fc01d736fe50cf5b977f755b675f11d',1,'setup():&#160;readPoseData.ino']]]
];

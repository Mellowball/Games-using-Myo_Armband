var searchData=
[
  ['myo_5fservice_5finfo_5fuuid',['MYO_SERVICE_INFO_UUID',['../myohw_8h.html#a990312e1dea31cbe65c41daa43773c26',1,'myohw.h']]],
  ['myohw_5fpacked',['MYOHW_PACKED',['../myohw_8h.html#ab2eee85c50f503741443fea6bb06ca2f',1,'myohw.h']]],
  ['myohw_5fstatic_5fassert_5fsized',['MYOHW_STATIC_ASSERT_SIZED',['../myohw_8h.html#abf17331220e98647e1c6e87423be1cda',1,'myohw.h']]]
];

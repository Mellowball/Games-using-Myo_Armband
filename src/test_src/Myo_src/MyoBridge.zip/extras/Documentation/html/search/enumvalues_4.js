var searchData=
[
  ['firmwareversioncharacteristic',['FirmwareVersionCharacteristic',['../group__myo__hardware.html#gga39811b63b77dda16ed982f292f034867a201e2cdce5699c8e1d23996cd4c6abf0',1,'myohw.h']]]
];

var searchData=
[
  ['functions_20for_20advanced_20usage',['Functions for Advanced Usage',['../group__advanced__funcs.html',1,'']]],
  ['functions_20for_20basic_20usage',['Functions for Basic Usage',['../group__basic__funcs.html',1,'']]],
  ['firmwareversioncharacteristic',['FirmwareVersionCharacteristic',['../group__myo__hardware.html#gga39811b63b77dda16ed982f292f034867a201e2cdce5699c8e1d23996cd4c6abf0',1,'myohw.h']]]
];

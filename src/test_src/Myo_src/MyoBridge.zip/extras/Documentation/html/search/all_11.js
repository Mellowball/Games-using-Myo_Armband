var searchData=
[
  ['vibrate',['vibrate',['../group__basic__funcs.html#ga023c11b4bead1fd3f512ad101fb25a93',1,'MyoBridge']]]
];
